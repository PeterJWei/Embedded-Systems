//Group 17
//Peter Wei (pwei) and Vruti Sivakumaran (vsivakum)
#include <exports.h>
void printvar(unsigned int x0, unsigned int x1, unsigned int x2, unsigned int x3, unsigned int x4, unsigned int x5) {
    printf("printing... %#x, %#x, %#x, %#x, %#x, %#x\n", x0, x1, x2, x3, x4, x5);
}
