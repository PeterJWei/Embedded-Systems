/*
 * globals.h: Defines global variables for the program.
 *
 * Author: Harry Q Bovik <hqbovik@andrew.cmu.edu>
 * Date:   Tue, 23 Oct 2007 11:20:33 -0400
 */

#ifndef GLOBALS_H
#define GLOBALS_H

extern int user_setup_stack_ptr;

#endif /* GLOBALS_H */
