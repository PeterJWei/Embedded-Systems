#ifndef CHECK_IC_H
#define CHECK_IC_H
void check_ic();
#endif
