#ifndef DISABLE_INTERRUPTS_H
#define DISABLE_INTERRUPTS_H
void disable_interrupts();
#endif
