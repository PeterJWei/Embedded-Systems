#ifndef ENABLE_IRQ_H
#define ENABLE_IRQ_H
void enable_irq();
#endif
