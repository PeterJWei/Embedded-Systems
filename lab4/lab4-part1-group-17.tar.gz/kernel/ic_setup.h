#ifndef IC_SETUP_H
#define IC_SETUP_H
void ic_setup();
#endif
