#ifndef C_SWI_HANDLER_H
#define C_SWI_HANDLER_H
int C_SWI_Handler(int swiNum, int *regs);
#endif
