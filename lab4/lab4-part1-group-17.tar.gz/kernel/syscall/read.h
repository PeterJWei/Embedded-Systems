#ifndef READ_H
#define READ_H
ssize_t read_handler(int fd, void *buf, size_t count);
#endif
