#ifndef TIME_H
#define TIME_H
unsigned long time_syscall();
void sleep_syscall(unsigned long millis);
#endif
