#ifndef WRITE_H
#define WRITE_H
ssize_t write_handler(int fd, const void *buf, size_t count);

#endif
