/** @file errno.c
 *
 * @brief Defines the global errno variable
 *
 * @author Mike Kasick <mkasick@andrew.cmu.edu>
 * @date   Sun, 07 Oct 2007 01:31:00 -0400
 */

int errno = 0;
